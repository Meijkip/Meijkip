var animatie = [];
var aantalBeeldjes = 3;
var nummer = 1;
var richting = 1;
var nieuwNummer = 0;

function preload() {
 for (var b = 0;b < aantalBeeldjes;b++) {
  nieuw_beeldje = loadImage("images/sprites/Jos_losse_beeldjes/Jos-" + b +".png");
  animatie.push(nieuw_beeldje);
 }

}
function setup() {
 canvas = createCanvas(460,460);
 canvas.parent('processing');
 noStroke();
 frameRate(5);
 textFont("Georgia");
 textSize(18);
}

function draw() {
  background('lavender');
  image(animatie[nummer],80,160,300,300);
  text("frameCount=" + frameCount,5,20);
  text("nummer=" + nummer,5,40);
  if (frameCount % 2 ==0) {
  nummer = nieuwNummer; 
  nieuwNummer()
 } else {
  nummer =2;
 }
}


function nieuwNummer() {
  if (nummer === 0) {
    nieuwNummer = 1;
  } else if (nummer === 1) {
    nieuwNummer = 0;
  }
}