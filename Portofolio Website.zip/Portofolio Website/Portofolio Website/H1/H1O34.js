var aantal = 100;
var x;
var y;
var diameter;

function setup() {
  canvas = createCanvas(451,451);
  canvas.parent('processing');
  frameRate(5);
  noLoop();
  strokeWeight(4);
  stroke('steelblue');
}

function draw() {
  background('white');

}